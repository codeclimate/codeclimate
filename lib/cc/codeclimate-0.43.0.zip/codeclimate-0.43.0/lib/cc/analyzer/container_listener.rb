module CC
  module Analyzer
    class ContainerListener
      def started(_data)
      end

      def timed_out(_data)
      end

      def finished(_data)
      end
    end
  end
end
